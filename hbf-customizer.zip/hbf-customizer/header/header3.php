<?php
/**
 * Template Name: Header 3 Custom Template
 * Author: Trần Quốc Thiều
 * Description: File hiển thị nội dung mẫu Header 3 với thông báo hỗ trợ qua Zalo.
 */

// Ngăn chặn truy cập trực tiếp vào file
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="hbf-header-template hbf-header-3" style="background: #f8f9fa; border: 1px dashed #ccc; padding: 20px; text-align: center; border-radius: 8px; margin: 10px 0;">
    <div class="hbf-header-content">
        <h3 style="color: #d32f2f; margin-bottom: 10px;">
            <i class="dashicons dashicons-warning" style="vertical-align: middle;"></i> 
            Phần Mẫu Header 3 đang cập nhật
        </h3>
        
        <p style="font-size: 16px; color: #333;">
            Nếu bạn cần gửi yêu cầu mẫu thiết kế cụ thể hoặc cần hỗ trợ kỹ thuật, vui lòng tham gia nhóm Zalo của chúng tôi.
        </p>

        <div class="zalo-contact-box" style="margin-top: 15px;">
            <a href="https://zalo.me/g/n0t7l3ikyqmz9brh0vnt" 
               target="_blank" 
               rel="nofollow" 
               style="display: inline-block; background: #0068ff; color: #fff; padding: 10px 25px; border-radius: 50px; text-decoration: none; font-weight: bold; transition: background 0.3s ease;">
               <span class="zalo-icon" style="background: #fff; color: #0068ff; border-radius: 50%; padding: 2px 6px; margin-right: 5px; font-size: 12px;">Z</span>
               Tham gia Nhóm Zalo Hỗ Trợ
            </a>
        </div>
    </div>
</div>

<style>
    .hbf-header-3 a:hover {
        background: #0056d2 !important;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
</style>