<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Ngăn chặn truy cập trực tiếp
}

/*-------------------------------------------------------
|  Lưu / lấy tùy chọn cho Header 1
*------------------------------------------------------*/
$header1_options = get_option( 'giaodien_header1_options', [] ); // Tên option riêng cho Header 1

// Lấy danh sách menu WordPress
$menus = wp_get_nav_menus();

// CHỈ XỬ LÝ KHI CÓ DỮ LIỆU POST ĐƯỢC GỬI, VÀ TAB HIỆN TẠI LÀ 'header1_settings', VÀ NONCE HỢP LỆ
if (
	isset( $_POST['giaodien_header1_options'] ) &&
	isset( $_GET['tab'] ) && $_GET['tab'] == 'header1_settings' && // ĐIỀU KIỆN QUAN TRỌNG ĐỂ TRÁNH LỖI NONCE
	check_admin_referer( 'giaodien_header1_save', 'giaodien_header1_nonce' ) // Nonce riêng cho Header 1
) {
	update_option( 'giaodien_header1_options', $_POST['giaodien_header1_options'] );
	$header1_options = $_POST['giaodien_header1_options']; // Cập nhật biến sau khi lưu
	echo '<div class="notice notice-success is-dismissible"><p>Cài đặt Header 1 đã được lưu.</p></div>';
}
?>

<div class="wrap">
    <h1>Cài đặt Header 1</h1>

    <form method="post" action="">
        <?php wp_nonce_field( 'giaodien_header1_save', 'giaodien_header1_nonce' ); ?>

        <table class="form-table">
            <tr>
                <th scope="row">Nội dung trên banner</th>
                <td>
                    <?php
                    $editor_id = 'gd_banner_editor';
                    $content   = $header1_options['banner_content'] ?? '';
                    $settings  = [ 'textarea_name' => 'giaodien_header1_options[banner_content]', 'media_buttons' => false, 'editor_height' => 150 ];
                    wp_editor( $content, $editor_id, $settings );
                    ?>
                    <p class="description">Nội dung này sẽ hiển thị ở vị trí phía trên banner và có thể sử dụng shortcode.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Chữ chạy (thông báo)</th>
                <td>
                    <input type="text" name="giaodien_header1_options[scrolling_text]"
                           value="<?php echo esc_attr( $header1_options['scrolling_text'] ?? '' ); ?>" class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">Hiệu ứng chữ chạy</th>
                <td>
                    <input type="checkbox" name="giaodien_header1_options[enable_scrolling]" value="1"
                        <?php checked( 1, $header1_options['enable_scrolling'] ?? 0 ); ?>>
                    <label for="giaodien_header1_options[enable_scrolling]">Bật hiệu ứng chữ chạy</label>
                </td>
            </tr>
            <tr>
                <th scope="row">Tốc độ chữ chạy (giây)</th>
                <td>
                    <input type="number" name="giaodien_header1_options[scrolling_speed]"
                           value="<?php echo esc_attr( $header1_options['scrolling_speed'] ?? '15' ); ?>" min="1" max="60" class="small-text"> s
                </td>
            </tr>
            <tr>
                <th scope="row">Màu nền cho chữ chạy</th>
                <td><input type="color" name="giaodien_header1_options[scrolling_background_color]"
                           value="<?php echo esc_attr( $header1_options['scrolling_background_color'] ?? '#000000' ); ?>"></td>
            </tr>
            <tr>
                <th scope="row">Màu chữ chạy</th>
                <td><input type="color" name="giaodien_header1_options[scrolling_text_color]"
                           value="<?php echo esc_attr( $header1_options['scrolling_text_color'] ?? '#ffffff' ); ?>"></td>
            </tr>
            <tr>
                <th scope="row">Tiêu đề chính (VD: HỘI ĐỒNG HỌ PHẠM)</th>
                <td><input type="text" name="giaodien_header1_options[main_title]"
                           value="<?php echo esc_attr( $header1_options['main_title'] ?? '' ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row">Mô tả (VD: TP. HỒ CHÍ MINH)</th>
                <td><input type="text" name="giaodien_header1_options[description]"
                           value="<?php echo esc_attr( $header1_options['description'] ?? '' ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row">Màu chữ Tiêu đề chính</th>
                <td><input type="color" name="giaodien_header1_options[main_title_color]"
                           value="<?php echo esc_attr( $header1_options['main_title_color'] ?? '#ffffff' ); ?>">
                           <p class="description">Màu cho tiêu đề chính. Nên chọn màu trắng để nổi bật trên nền đỏ.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Màu chữ Mô tả</th>
                <td><input type="color" name="giaodien_header1_options[description_color]"
                           value="<?php echo esc_attr( $header1_options['description_color'] ?? '#ffffff' ); ?>">
                           <p class="description">Màu cho mô tả. Nên chọn màu trắng để nổi bật trên nền đỏ.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Ảnh Logo</th>
                <td>
                    <input id="gd-header1-logo" type="text" name="giaodien_header1_options[logo_image]"
                           value="<?php echo esc_attr( $header1_options['logo_image'] ?? '' ); ?>" class="regular-text">
                    <button type="button" class="button gd-select-image" data-target="#gd-header1-logo">Chọn từ Media</button>
                    <p class="description">Chọn ảnh logo sẽ hiển thị bên trái header. Ảnh nên có hình vuông để hiển thị đẹp nhất với hiệu ứng bo tròn.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">URL của Logo</th>
                <td>
                    <input type="url" name="giaodien_header1_options[logo_url]"
                           value="<?php echo esc_url( $header1_options['logo_url'] ?? '' ); ?>" class="regular-text" placeholder="https://example.com">
                    <p class="description">Nhập đường dẫn khi nhấp vào logo (để trống nếu không muốn liên kết).</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Ảnh nền Header</th>
                <td>
                    <input id="gd-header1-background-image" type="text" name="giaodien_header1_options[background_image]"
                           value="<?php echo esc_attr( $header1_options['background_image'] ?? '' ); ?>" class="regular-text">
                    <button type="button" class="button gd-select-image" data-target="#gd-header1-background-image">Chọn từ Media</button>
                    <p class="description">Chọn ảnh nền lớn cho phần header. Nên dùng ảnh có kích thước rộng (ví dụ: 1920x200px).</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Vị trí ảnh nền</th>
                <td>
                    <select name="giaodien_header1_options[background_position]">
                        <?php
                        $positions = [
                            'left top'      => 'Trái trên',
                            'left center'   => 'Trái giữa',
                            'left bottom'   => 'Trái dưới',
                            'center top'    => 'Giữa trên',
                            'center center' => 'Giữa giữa',
                            'center bottom' => 'Giữa dưới',
                            'right top'     => 'Phải trên',
                            'right center'  => 'Phải giữa',
                            'right bottom'  => 'Phải dưới',
                        ];
                        foreach ($positions as $value => $label) :
                        ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected( $header1_options['background_position'] ?? 'center bottom', $value ); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">Chọn vị trí hiển thị của ảnh nền để hiển thị đoạn mong muốn.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Chiều cao Header (px)</th>
                <td>
                    <input type="number" name="giaodien_header1_options[header_height]"
                           value="<?php echo esc_attr( $header1_options['header_height'] ?? '160' ); ?>" min="100" class="small-text"> px
                    <p class="description">Thiết lập chiều cao tối thiểu cho toàn bộ khu vực Header (logo + chữ + ảnh nền).</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Màu nền phụ Header</th>
                <td><input type="color" name="giaodien_header1_options[background_color]"
                           value="<?php echo esc_attr( $header1_options['background_color'] ?? '#ffffff' ); ?>">
                           <p class="description">Màu này sẽ hiển thị nếu không có ảnh nền hoặc ở các khu vực trống.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Chọn Menu Header</th>
                <td>
                    <select name="giaodien_header1_options[menu_slug]">
                        <option value="">-- Không chọn --</option>
                        <?php foreach ( $menus as $menu ) : ?>
                            <option value="<?php echo esc_attr( $menu->slug ); ?>"
                                <?php selected( $header1_options['menu_slug'] ?? '', $menu->slug ); ?>>
                                <?php echo esc_html( $menu->name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">Chọn menu WordPress sẽ hiển thị dưới Header.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Màu nền Menu</th>
                <td><input type="color" name="giaodien_header1_options[menu_background_color]"
                           value="<?php echo esc_attr( $header1_options['menu_background_color'] ?? '#c8102e' ); ?>"></td>
            </tr>
            <tr>
                <th scope="row">Màu chữ Menu</th>
                <td><input type="color" name="giaodien_header1_options[menu_text_color]"
                           value="<?php echo esc_attr( $header1_options['menu_text_color'] ?? '#ffffff' ); ?>"></td>
            </tr>
            <tr>
                <th scope="row">Màu nền Submenu</th>
                <td><input type="color" name="giaodien_header1_options[submenu_background_color]"
                           value="<?php echo esc_attr( $header1_options['submenu_background_color'] ?? '#ffffff' ); ?>">
                           <p class="description">Màu nền cho các menu con khi nhấp chuột.</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Icon trang chủ (Font Awesome)</th>
                <td><input type="text" name="giaodien_header1_options[home_icon]"
                           value="<?php echo esc_attr( $header1_options['home_icon'] ?? '' ); ?>" class="regular-text">
                           <p class="description">Nhập class Font Awesome cho icon trang chủ (ví dụ: `fa-solid fa-house`).</p>
                </td>
            </tr>
            <tr>
                <th scope="row">Kích thước icon (px)</th>
                <td><input type="number" name="giaodien_header1_options[home_icon_height]"
                           value="<?php echo esc_attr( $header1_options['home_icon_height'] ?? '24' ); ?>" min="1" class="small-text"> px</td>
            </tr>
        </table>

        <?php submit_button( 'Lưu thay đổi cho Header 1' ); ?>

        <h2 style="margin-top:30px;">Xem trước giao diện Header 1</h2>
        
        <?php if ( ! empty( $header1_options['scrolling_text'] ) && ( $header1_options['enable_scrolling'] ?? 0 ) == 1 ) : ?>
        <div class="gd-preview-scrolling-text" style="
            background-color: <?php echo esc_attr( $header1_options['scrolling_background_color'] ?? '#000000' ); ?>;
            color: <?php echo esc_attr( $header1_options['scrolling_text_color'] ?? '#ffffff' ); ?>;
            overflow: hidden;
            white-space: nowrap;
            padding: 5px 0;
            font-size: 14px;
        ">
            <span class="scrolling-text" style="
                animation: scroll-left <?php echo esc_attr( $header1_options['scrolling_speed'] ?? '15' ); ?>s linear infinite;
            ">
                <?php echo esc_html( $header1_options['scrolling_text'] ); ?>
            </span>
        </div>
        <?php endif; ?>

        <?php if ( ! empty( $header1_options['banner_content'] ) ) : ?>
        <div class="gd-preview-banner-content" style="padding: 15px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 10px;">
            <?php
            $banner_content = do_shortcode( wp_kses_post( $header1_options['banner_content'] ) );
            echo $banner_content;
            ?>
        </div>
        <?php endif; ?>

        <div class="gd-preview-header1-final" style="
            background-color: <?php echo esc_attr( $header1_options['background_color'] ?? '#ffffff' ); ?>;
            <?php
            // Get header height from options, default to 160px
            $header_height = esc_attr( $header1_options['header_height'] ?? '160' );
            ?>
            <?php if ( ! empty( $header1_options['background_image'] ) ) : ?>
                background-image: url(<?php echo esc_url( $header1_options['background_image'] ); ?>);
                background-size: cover;
                background-position: <?php echo esc_attr( $header1_options['background_position'] ?? 'center bottom' ); ?>;
                background-repeat: no-repeat;
            <?php endif; ?>
            display: flex;
            align-items: center;
            padding: 15px 25px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            min-height: <?php echo $header_height; ?>px;
            position: relative;
            overflow: hidden;
        ">
            <?php if ( ! empty( $header1_options['logo_image'] ) ) : ?>
                <div class="gd-header1-logo-wrapper" style="
                    flex-shrink: 0;
                    margin-right: 20px;
                    width: 100px;
                    height: 100px;
                    border-radius: 50%;
                    overflow: hidden;
                    border: 2px solid #eee;
                    background: rgba(255,255,255,0.7);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                ">
                    <?php 
                    // Kiểm tra và thêm link cho logo
                    $logo_url = esc_url($header1_options['logo_url'] ?? '');
                    if (!empty($logo_url)) {
                        echo '<a href="' . $logo_url . '">';
                    }
                    ?>
                    <img src="<?php echo esc_url( $header1_options['logo_image'] ); ?>" alt="Logo" style="
                        max-width: 100%;
                        max-height: 100%;
                        object-fit: contain;
                    ">
                    <?php if (!empty($logo_url)) {
                        echo '</a>';
                    }
                    ?>
                </div>
            <?php endif; ?>

            <div class="gd-header1-text-content" style="
                flex-grow: 1;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 1;
                position: relative;
                margin: 0;
                max-width: none;
            ">
                <?php if ( ! empty( $header1_options['main_title'] ) ) : ?>
                    <h3 style="
                        color: <?php echo esc_attr( $header1_options['main_title_color'] ?? '#ffffff' ); ?>;
                        margin: 0;
                        font-size: 28px;
                        font-weight: bold;
                        text-shadow: 1px 1px 3px rgba(0,0,0,0.4);
                        line-height: 1.2;
                    ">
                        <?php echo esc_html( $header1_options['main_title'] ); ?>
                    </h3>
                <?php endif; ?>

                <?php if ( ! empty( $header1_options['description'] ) ) : ?>
                    <p style="
                        color: <?php echo esc_attr( $header1_options['description_color'] ?? '#ffffff' ); ?>;
                        margin: 5px 0 0 0;
                        font-size: 18px;
                        text-shadow: 1px 1px 3px rgba(0,0,0,0.4);
                        line-height: 1.2;
                    ">
                        <?php echo esc_html( $header1_options['description'] ); ?>
                    </p>
                <?php endif; ?>
            </div>
            <div style="flex-shrink: 0; width: 100px; margin-left: 20px;"></div>
        </div>

        <?php if ( ! empty( $header1_options['menu_slug'] ) && ( $menu = wp_get_nav_menu_object( $header1_options['menu_slug'] ) ) ) : ?>
            <div class="gd-preview-menu-header1"
                 style="
                    background:<?php echo esc_attr( $header1_options['menu_background_color'] ?? '#c8102e' ); ?>;
                    margin-top: 10px;
                    padding: 10px 0;
                    border-radius: 4px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                 ">
                <?php
                // Tùy chỉnh Walker để thay thế "TRANG CHỦ" bằng icon
                class GD_Custom_Walker extends Walker_Nav_Menu {
                    private $home_icon = '';
                    private $home_icon_height = '';

                    public function __construct($home_icon, $home_icon_height) {
                        $this->home_icon = $home_icon;
                        $this->home_icon_height = $home_icon_height;
                    }
                    
                    public function start_el(&$output, $item, $depth = 0, $args = [], $id = 0) {
                        // Thêm class cho thẻ li nếu là item có submenu
                        if ($item->has_children) {
                            $output .= '<li class="' . implode(' ', $item->classes) . ' menu-item-has-children">';
                        } else {
                            $output .= '<li class="' . implode(' ', $item->classes) . '">';
                        }

                        $atts = [];
                        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
                        $atts['target'] = ! empty( $item->target )     ? $item->target     : '';
                        $atts['rel']    = ! empty( $item->xfn )        ? $item->xfn        : '';
                        $atts['href']   = ! empty( $item->url )        ? $item->url        : '';

                        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );
                        $attributes = '';
                        foreach ( $atts as $attr => $value ) {
                            if ( ! empty( $value ) ) {
                                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                                $attributes .= ' ' . $attr . '="' . $value . '"';
                            }
                        }

                        $item_output = $args->before;
                        $item_output .= '<a' . $attributes . '>';
                        $item_output .= $args->link_before;

                        // Kiểm tra nếu là trang chủ và có icon tùy chỉnh
                        $is_home = (
                            $item->url == home_url('/') ||
                            $item->object == 'page' && get_option( 'page_on_front' ) == $item->object_id
                        );

                        if ( $is_home && ! empty($this->home_icon) ) {
                            $item_output .= '<span class="gd-menu-icon" style="font-size: ' . esc_attr($this->home_icon_height) . 'px;">';
                            $item_output .= '<i class="' . esc_attr($this->home_icon) . '"></i>';
                            $item_output .= '</span>';
                        } else {
                            $item_output .= apply_filters( 'the_title', $item->title, $item->ID );
                        }
                        
                        $item_output .= $args->link_after;
                        $item_output .= '</a>';
                        $item_output .= $args->after;

                        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
                    }
                }
                
                wp_nav_menu( [
                    'menu'        => $menu->term_id,
                    'container'   => false,
                    'menu_class'  => 'gd-menu-ul-header1',
                    'fallback_cb' => false,
                    'walker'      => new GD_Custom_Walker( 
                        $header1_options['home_icon'] ?? '',
                        $header1_options['home_icon_height'] ?? '24' 
                    ),
                ] );
                ?>
            </div>
        <?php endif; ?>
    </form>
</div>

<?php wp_enqueue_media(); // Kích hoạt Media Uploader ?>
<?php
// Bổ sung các script cần thiết cho trình soạn thảo
function enqueue_header1_admin_scripts() {
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'editor' );
    wp_enqueue_script( 'thickbox' );
    wp_enqueue_style( 'thickbox' );
}
add_action( 'admin_enqueue_scripts', 'enqueue_header1_admin_scripts' );
?>

<style>
    /* Nhúng Font Awesome */
    @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css');

    /* CSS cho phần xem trước Header 1 cuối cùng */
    .gd-preview-header1-final {
        /* Style được inline trong HTML để dễ dàng tùy biến qua PHP */
    }
    .gd-header1-logo-wrapper {
        /* Style được inline trong HTML */
    }
    .gd-header1-logo-wrapper img {
        /* Style được inline trong HTML */
    }
    .gd-header1-text-content {
        /* Đã di chuyển nhiều style inline */
        display: flex; /* Sử dụng flexbox để căn giữa 2 dòng chữ */
        flex-direction: column; /* Xếp 2 dòng chữ theo cột */
        justify-content: center; /* Căn giữa theo chiều dọc */
        align-items: center; /* Căn giữa theo chiều ngang */
        text-align: center; /* Đảm bảo văn bản trong nó cũng căn giữa */
    }
    .gd-header1-text-content h3,
    .gd-header1-text-content p {
        /* Style được inline trong HTML */
        line-height: 1.2; /* Tối ưu khoảng cách dòng */
    }

    /* CSS cho Menu Header 1 */
    .gd-menu-ul-header1 {
        display: flex;
        justify-content: center;
        gap: 25px;
        list-style: none;
        margin: 0;
        padding: 0;
        flex-wrap: wrap;
    }
    .gd-menu-ul-header1 li { position: relative; }
    .gd-menu-ul-header1 > li > a {
        text-decoration: none;
        color: <?php echo esc_attr( $header1_options['menu_text_color'] ?? '#ffffff' ); ?>; /* Màu chữ menu */
        text-transform: uppercase;
        font-weight: bold;
        padding: 5px 10px;
        display: flex; /* Bật Flexbox cho thẻ a */
        align-items: center; /* Căn giữa theo chiều dọc */
        justify-content: center; /* Căn giữa theo chiều ngang */
        height: 100%; /* Đảm bảo thẻ a chiếm toàn bộ chiều cao */
    }
    /* Thêm CSS cho icon trang chủ */
    .gd-menu-ul-header1 li.menu-item-home > a .gd-menu-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%; /* Giúp icon căn giữa */
        font-size: <?php echo esc_attr($header1_options['home_icon_height'] ?? '24'); ?>px;
        color: <?php echo esc_attr( $header1_options['menu_text_color'] ?? '#ffffff' ); ?>;
    }
    .gd-menu-ul-header1 li.menu-item-home > a {
        padding: 0;
    }
    .gd-menu-ul-header1 li.menu-item-home {
        display: flex; /* để căn chỉnh icon */
        align-items: center; /* căn chỉnh icon theo chiều dọc */
    }

    /* Submenu Header 1 */
    .gd-menu-ul-header1 li ul {
        position: absolute;
        display: none; /* Khởi đầu ẩn */
        top: 100%;
        left: 0;
        background: <?php echo esc_attr( $header1_options['submenu_background_color'] ?? '#ffffff' ); ?>; /* Nền submenu */
        padding: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,.15);
        z-index: 999;
        min-width: 200px;
        list-style: none; /* Đảm bảo submenu không có bullet */
        margin: 0;
    }
    .gd-menu-ul-header1 li.show-submenu > ul {
        display: flex; /* Chỉ hiển thị khi có class này */
        flex-direction: column; /* Đã sửa: Xếp các mục con theo cột */
        flex-wrap: wrap;
        gap: 10px; /* Khoảng cách giữa các mục con */
    }
    .gd-menu-ul-header1 li ul li   { margin-bottom: 0; }
    .gd-menu-ul-header1 ul li a {
        color: #000; /* Màu chữ submenu */
        text-transform: none;
        font-weight: normal;
        text-decoration: none;
        display: block; /* Để padding và hover hoạt động tốt */
        padding: 5px 10px;
        white-space: nowrap; /* Ngăn chữ bị ngắt dòng */
    }
    .gd-menu-ul-header1 li ul li:last-child { margin-bottom: 0; }
    
    /* Hiệu ứng chữ chạy */
    .gd-preview-scrolling-text {
        overflow: hidden;
        white-space: nowrap;
        background-color: <?php echo esc_attr( $header1_options['scrolling_background_color'] ?? '#000000' ); ?>;
        color: <?php echo esc_attr( $header1_options['scrolling_text_color'] ?? '#ffffff' ); ?>;
    }
    .gd-preview-scrolling-text .scrolling-text {
        display: inline-block;
        animation: scroll-left <?php echo esc_attr( $header1_options['scrolling_speed'] ?? '15' ); ?>s linear infinite;
        padding-left: 100%; /* Bắt đầu từ ngoài cùng bên phải */
    }
    @keyframes scroll-left {
        0% { transform: translateX(0); }
        100% { transform: translateX(-100%); }
    }
    
    /* === Bắt đầu các quy tắc cho Mobile === */
    @media only screen and (max-width: 768px) {
        .gd-preview-header1-final {
            flex-direction: column; /* Xếp logo và text theo chiều dọc */
            text-align: center;
            padding: 10px;
            min-height: auto !important; /* Bỏ min-height cố định */
            height: auto !important;
        }

        .gd-header1-logo-wrapper {
            margin: 0 0 10px 0 !important; /* Tạo khoảng cách dưới logo */
            width: 80px !important;
            height: 80px !important;
        }

        .gd-header1-text-content {
            flex-direction: column !important; /* Đảm bảo text luôn xếp theo cột */
            align-items: center !important;
            margin-bottom: 10px;
        }

        .gd-header1-text-content h3 {
            font-size: 20px !important; /* Giảm kích thước tiêu đề chính */
        }
        
        .gd-header1-text-content p {
            font-size: 14px !important; /* Giảm kích thước mô tả */
        }

        .gd-menu-ul-header1 {
            flex-direction: column; /* Xếp menu theo chiều dọc */
            gap: 10px;
            align-items: center; /* Căn giữa các mục menu */
        }

        .gd-menu-ul-header1 li {
            width: 100%; /* Đảm bảo mỗi mục menu chiếm toàn bộ chiều rộng */
            text-align: center;
        }
        
        .gd-menu-ul-header1 li > a {
            justify-content: center; /* Căn giữa chữ trong menu */
            padding: 5px !important;
        }

        .gd-menu-ul-header1 li ul {
            position: relative; /* Hiển thị submenu ngay bên dưới mục cha */
            min-width: auto;
            left: 0;
            top: auto;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: none;
        }
        .gd-menu-ul-header1 li ul li a {
            padding: 5px 10px !important;
        }
    }
    /* === Kết thúc các quy tắc cho Mobile === */

</style>

<script>
jQuery(function ($) {
	/* ---------- Chọn ảnh từ Media ---------- */
	$('.gd-select-image').on('click', function (e) {
		e.preventDefault();
		const button = $(this);
		const targetField = button.data('target'); // Lấy ID của trường input đích từ data-target

		const frame = wp.media({
			title: 'Chọn ảnh',
			button: { text: 'Chọn ảnh' },
			multiple: false
		});

		frame.on('select', function () {
			const attachment = frame.state().get('selection').first().toJSON();
			$(targetField).val(attachment.url); // Đặt URL vào trường input đích
            // Cập nhật xem trước logo nếu là trường logo
            if (targetField === '#gd-header1-logo') {
                $('.gd-header1-logo-wrapper img').attr('src', attachment.url);
            }
            // Cập nhật xem trước ảnh nền nếu là trường ảnh nền
            if (targetField === '#gd-header1-background-image') {
                $('.gd-preview-header1-final').css('background-image', 'url(' + attachment.url + ')');
                $('.gd-preview-header1-final').css('background-size', 'cover');
                $('.gd-preview-header1-final').css('background-repeat', 'no-repeat');
            }
		});

		frame.open();
	});

    // Cập nhật xem trước khi các input thay đổi
    $('input[name="giaodien_header1_options[main_title]"]').on('input', function() {
        $('.gd-header1-text-content h3').text($(this).val());
    });
    $('input[name="giaodien_header1_options[description]"]').on('input', function() {
        $('.gd-header1-text-content p').text($(this).val());
    });
    // Cập nhật màu chữ tiêu đề chính
    $('input[name="giaodien_header1_options[main_title_color]"]').on('input', function() {
        $('.gd-header1-text-content h3').css('color', $(this).val());
    });
    // Cập nhật màu chữ mô tả
    $('input[name="giaodien_header1_options[description_color]"]').on('input', function() {
        $('.gd-header1-text-content p').css('color', $(this).val());
    });
    $('input[name="giaodien_header1_options[background_color]"]').on('input', function() {
        $('.gd-preview-header1-final').css('background-color', $(this).val());
    });
    $('#gd-header1-logo').on('input', function() {
        $('.gd-header1-logo-wrapper img').attr('src', $(this).val());
    });

    // Cập nhật xem trước background_position
    $('select[name="giaodien_header1_options[background_position]"]').on('change', function() {
        $('.gd-preview-header1-final').css('background-position', $(this).val());
    });

    // Cập nhật xem trước chiều cao header
    $('input[name="giaodien_header1_options[header_height]"]').on('input', function() {
        const newHeight = $(this).val() + 'px';
        $('.gd-preview-header1-final').css('min-height', newHeight);
    });

    // Cập nhật xem trước màu nền menu
    $('input[name="giaodien_header1_options[menu_background_color]"]').on('input', function() {
        $('.gd-preview-menu-header1').css('background', $(this).val());
    });

    // Cập nhật xem trước màu chữ menu
    $('input[name="giaodien_header1_options[menu_text_color]"]').on('input', function() {
        $('.gd-preview-menu-header1 .gd-menu-ul-header1 li a').css('color', $(this).val());
    });
    
    // Cập nhật màu nền submenu
    $('input[name="giaodien_header1_options[submenu_background_color]"]').on('input', function() {
        $('.gd-menu-ul-header1 li ul').css('background', $(this).val());
    });
    
    // Cập nhật chiều cao icon
    $('input[name="giaodien_header1_options[home_icon_height]"]').on('input', function() {
        $('.gd-menu-ul-header1 li.menu-item-home > a .gd-menu-icon').css('font-size', $(this).val() + 'px');
    });

    // Cập nhật xem trước chữ chạy
    $('input[name="giaodien_header1_options[scrolling_text]"]').on('input', function() {
        $('.gd-preview-scrolling-text .scrolling-text').text($(this).val());
    });
    $('input[name="giaodien_header1_options[enable_scrolling]"]').on('change', function() {
        if ($(this).is(':checked')) {
            $('.gd-preview-scrolling-text').show();
        } else {
            $('.gd-preview-scrolling-text').hide();
        }
    });

    /* ---------- Xử lý sự kiện click để xổ submenu ---------- */
    $('.gd-menu-ul-header1 > li > a').on('click', function(e) {
        // Kiểm tra xem mục menu hiện tại có menu con không
        const hasSubmenu = $(this).parent().hasClass('menu-item-has-children');
        
        // Nếu có submenu, ngăn chặn hành vi mặc định của link
        if (hasSubmenu) {
            e.preventDefault();
        }

        // Đóng tất cả các submenu đang mở khác
        $('.gd-menu-ul-header1 > li').not($(this).parent()).removeClass('show-submenu');

        // Bật/tắt submenu của mục menu hiện tại
        $(this).parent().toggleClass('show-submenu');
    });

    // Đóng submenu khi click ra ngoài
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.gd-menu-ul-header1').length) {
            $('.gd-menu-ul-header1 li.show-submenu').removeClass('show-submenu');
        }
    });
});
</script>