<?php
/**
 * File: header1.php
 * Cập nhật: Submenu nằm ngang chia 2 cột giống ảnh mẫu.
 * Giữ nguyên các chức năng tùy chỉnh khác.
 */

$default_options = [
    'bg_color'       => '#d60000',
    'bg_image'       => '', 
    'header_height'  => '286',
    'dragon_left'    => '',
    'dragon_right'   => '',
    'logo_url'       => '',
    'menu_id'        => 0,
    'menu_shortcode' => '',
    'site_title'     => 'TRANG THÔNG TIN ĐIỆN TỬ',
    'site_desc'      => 'HỌ TRẦN LÊ ĐẠI TÔN',
    'bar_bg_color'   => '#b89851',
    'bar_text_color' => '#ffffff'
];
// Đổi từ header4_configs sang header1_configs[cite: 1]
$options = get_option('header1_configs', $default_options);

// Đổi action kiểm tra lưu dữ liệu[cite: 1]
if (isset($_POST['action']) && $_POST['action'] == 'save_header1_config' && current_user_can('manage_options')) {
    update_option('header1_configs', $_POST['configs']);
    wp_send_json_success();
    exit;
}

if (is_admin()) { wp_enqueue_media(); }
?>

<div id="header1-display" style="
    background-color: <?php echo esc_attr($options['bg_color']); ?>; 
    background-image: url('<?php echo esc_url($options['bg_image']); ?>');
    height: <?php echo esc_attr($options['header_height']); ?>px;
    background-size: 100% 100%; background-repeat: no-repeat;">
    
    <div class="h1-main-wrapper">
        <div class="h1-logo-center">
            <?php if ($options['logo_url']): ?>
                <img src="<?php echo esc_url($options['logo_url']); ?>" id="preview-logo">
            <?php endif; ?>
        </div>

        <div class="h1-content-row">
            <div class="h1-dragon-box left">
                <img src="<?php echo esc_url($options['dragon_left']); ?>" id="preview-left">
            </div>

            <div class="h1-center-text">
                <h1 id="preview-title"><?php echo esc_html($options['site_title']); ?></h1>
                <p id="preview-desc" style="font-weight: bold; margin-top: 5px;"><?php echo esc_html($options['site_desc']); ?></p>
            </div>

            <div class="h1-dragon-box right">
                <img src="<?php echo esc_url($options['dragon_right']); ?>" id="preview-right">
            </div>
        </div>
    </div>

    <div class="h1-bottom-bar" id="preview-bar-bg" style="background-color: <?php echo esc_attr($options['bar_bg_color']); ?>;">
        <div class="h1-inner-bar" id="preview-bar-text" style="color: <?php echo esc_attr($options['bar_text_color']); ?>;">
            <div class="h1-date"><?php echo date_i18n('l, d/m/Y'); ?></div>
            <nav class="h1-menu-nav">
                <?php 
                if (!empty($options['menu_id']) && $options['menu_id'] != '0') {
                    wp_nav_menu([
                        'menu' => $options['menu_id'],
                        'container' => false,
                        'menu_class' => 'h1-horizontal-menu'
                    ]);
                } elseif (!empty($options['menu_shortcode'])) {
                    echo '<div class="h1-shortcode-wrap">' . do_shortcode($options['menu_shortcode']) . '</div>';
                }
                ?>
            </nav>
        </div>
    </div>
</div>

<?php if (current_user_can('manage_options')) : ?>
<div id="header1-admin-panel" style="background:#fff; padding:20px; border:1px solid #ccc; margin-top:20px; font-family:sans-serif;">
    <h3 style="color:#2271b1; border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0;">CÀI ĐẶT HEADER 1</h3>
    <div style="display: flex; gap: 20px; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 250px;">
            <p><label>Nền Header:</label><br><input type="color" id="set-bg" value="<?php echo $options['bg_color']; ?>"></p>
            <p><label>Nền Menu:</label><br><input type="color" id="set-bar-bg" value="<?php echo $options['bar_bg_color']; ?>"></p>
            <p><label>Chữ Menu:</label><br><input type="color" id="set-bar-text" value="<?php echo $options['bar_text_color']; ?>"></p>
            <p><label>Chiều cao: <span id="height-val"><?php echo $options['header_height']; ?></span>px</label>
            <input type="range" id="set-height" min="150" max="600" value="<?php echo $options['header_height']; ?>" style="width:100%;"></p>
        </div>
        <div style="flex: 1; min-width: 250px;">
            <p><label>Tiêu đề:</label><input type="text" id="set-title" value="<?php echo esc_attr($options['site_title']); ?>" style="width:100%;"></p>
            <p><label>Mô tả:</label><input type="text" id="set-desc" value="<?php echo esc_attr($options['site_desc']); ?>" style="width:100%;"></p>
            <p><label>Chọn Menu:</label>
                <select id="set-menu-id" style="width:100%;">
                    <option value="0">-- Shortcode --</option>
                    <?php foreach (wp_get_nav_menus() as $menu) : ?>
                        <option value="<?php echo $menu->term_id; ?>" <?php selected($options['menu_id'], $menu->term_id); ?>><?php echo $menu->name; ?></option>
                    <?php endforeach; ?>
                </select>
            </p>
            <p><label>Shortcode:</label><input type="text" id="set-shortcode" value="<?php echo esc_attr($options['menu_shortcode']); ?>" style="width:100%;"></p>
        </div>
        <div style="flex: 1; min-width: 250px;">
            <div class="media-row" style="margin-bottom:10px;"><label>Ảnh nền:</label><br><input type="text" id="set-bg-img" value="<?php echo $options['bg_image']; ?>" style="width:70%"><button class="btn-upload" data-target="#set-bg-img" style="width:25%">Chọn</button></div>
            <div class="media-row" style="margin-bottom:10px;"><label>Logo:</label><br><input type="text" id="set-logo" value="<?php echo $options['logo_url']; ?>" style="width:70%"><button class="btn-upload" data-target="#set-logo" style="width:25%">Chọn</button></div>
            <div class="media-row" style="margin-bottom:10px;"><label>Rồng Trái:</label><br><input type="text" id="set-left" value="<?php echo $options['dragon_left']; ?>" style="width:70%"><button class="btn-upload" data-target="#set-left" style="width:25%">Chọn</button></div>
            <div class="media-row" style="margin-bottom:10px;"><label>Rồng Phải:</label><br><input type="text" id="set-right" value="<?php echo $options['dragon_right']; ?>" style="width:70%"><button class="btn-upload" data-target="#set-right" style="width:25%">Chọn</button></div>
        </div>
    </div>
    <button id="btn-save-h1" class="button button-primary" style="margin-top:20px; padding: 5px 25px; height: auto;">LƯU CÀI ĐẶT</button>
</div>

<script>
jQuery(document).ready(function($) {
    $('.btn-upload').click(function(e) {
        e.preventDefault();
        var target = $($(this).data('target'));
        var frame = wp.media({ title: 'Chọn ảnh', multiple: false }).on('select', function() {
            target.val(frame.state().get('selection').first().toJSON().url);
        }).open();
    });
    $('#set-height').on('input', function() { $('#height-val').text($(this).val()); $('#header1-display').css('height', $(this).val() + 'px'); });
    
    // Đổi ID nút lưu và action sang header1[cite: 1]
    $('#btn-save-h1').click(function() {
        var configs = {
            bg_color: $('#set-bg').val(), bg_image: $('#set-bg-img').val(),
            bar_bg_color: $('#set-bar-bg').val(), bar_text_color: $('#set-bar-text').val(),
            header_height: $('#set-height').val(), site_title: $('#set-title').val(), site_desc: $('#set-desc').val(),
            menu_id: $('#set-menu-id').val(), menu_shortcode: $('#set-shortcode').val(),
            logo_url: $('#set-logo').val(), dragon_left: $('#set-left').val(), dragon_right: $('#set-right').val()
        };
        $.post('', { action: 'save_header1_config', configs: configs }, function() { alert('Đã lưu!'); location.reload(); });
    });
});
</script>
<?php endif; ?>

<style>
/* CSS HIỂN THỊ CHÍNH */
#header1-display { width: 100%; display: flex; flex-direction: column; position: relative; overflow: visible; }
.h1-main-wrapper { flex: 1; position: relative; display: flex; align-items: center; justify-content: center; padding: 0 20px; }
.h1-logo-center { position: absolute; top: 10px; left: 50%; transform: translateX(-50%); z-index: 10; }
#preview-logo { max-height: 80px; width: auto; }
.h1-content-row { display: flex; width: 100%; align-items: center; justify-content: space-between; margin-top: 50px; }
.h1-dragon-box { width: 22%; }
.h1-dragon-box img { width: 100%; max-height: 160px; object-fit: contain; }
.h1-center-text { text-align: center; color: #fff; flex: 1; text-shadow: 2px 2px 4px rgba(0,0,0,0.5); }
.h1-center-text h1 { font-size: 28px; text-transform: uppercase; margin: 0; }

.h1-bottom-bar { padding: 5px 0; width: 100%; position: relative; z-index: 999; }
.h1-inner-bar { max-width: 1250px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 15px; font-size: 13px; font-weight: bold; }

/* MENU CHÍNH */
ul.h1-horizontal-menu { list-style: none; margin: 0; padding: 0; display: flex; gap: 20px; }
ul.h1-horizontal-menu li { position: relative; }
ul.h1-horizontal-menu li a { color: inherit; text-decoration: none; text-transform: uppercase; padding: 10px 0; display: block; }

/* SUBMENU CHIA 2 CỘT NẰM NGANG */
ul.h1-horizontal-menu li ul.sub-menu {
    position: absolute; top: 100%; left: 0; 
    background: #e5b0b0; 
    display: none; padding: 5px; margin: 0; list-style: none; 
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    width: 550px; 
    flex-wrap: wrap; border-radius: 8px; border: 1px solid rgba(0,0,0,0.1);
}
ul.h1-horizontal-menu li:hover > ul.sub-menu { display: flex; }

ul.h1-horizontal-menu li ul.sub-menu li { 
    width: 50%; 
    box-sizing: border-box; 
    border-right: 1px solid rgba(255,255,255,0.3);
    border-bottom: 1px solid rgba(255,255,255,0.3);
}
ul.h1-horizontal-menu li ul.sub-menu li:nth-child(2n) { border-right: none; }

ul.h1-horizontal-menu li ul.sub-menu li a { 
    padding: 15px 20px; 
    color: #222; 
    display: block; 
    text-transform: none; 
    font-size: 14px; 
    line-height: 1.4;
    font-weight: 500;
}
ul.h1-horizontal-menu li ul.sub-menu li a:hover { 
    background: rgba(255,255,255,0.2); 
    color: #d60000; 
}

@media (max-width: 768px) { .h1-dragon-box { display: none; } }
</style>