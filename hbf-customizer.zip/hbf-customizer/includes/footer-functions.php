<?php
function hbf_render_footer_tab() {
    $dir = HBF_PATH . 'footer/';
    $files = glob($dir . "*.php");
    $view_file = isset($_GET['view_footer']) ? sanitize_text_field($_GET['view_footer']) : '';

    if ($view_file && file_exists($dir . $view_file)) {
        echo '<div style="margin-bottom: 20px;"><a href="?page=hbf-customizer&tab=footer" class="button"><span class="dashicons dashicons-arrow-left-alt" style="vertical-align: middle; padding-top: 4px;"></span> Quay lại danh sách Footer</a></div>';
        echo '<div class="hbf-preview-container" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 4px;">';
        include $dir . $view_file;
        echo '</div>';
        return;
    }

    echo '<div class="hbf-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 20px 0;">';
    if (!empty($files)) {
        foreach ($files as $file) {
            $file_name = basename($file);
            $display_title = ucfirst(str_replace('.php', '', $file_name));
            $link = "?page=hbf-customizer&tab=footer&view_footer=" . $file_name;
            ?>
            <div class="hbf-card" onclick="location.href='<?php echo $link; ?>'" style="background: #fff; border: 1px solid #e5e5e5; border-radius: 4px; padding: 40px 20px; text-align: center; cursor: pointer; transition: all 0.2s ease-in-out;">
                <div class="hbf-icon" style="margin-bottom: 15px;"><span class="dashicons dashicons-editor-insertmore" style="font-size: 40px; width: 40px; height: 40px; color: #2271b1;"></span></div>
                <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 600; color: #1d2327;"><?php echo esc_html($display_title); ?></h3>
                <p style="color: #646970; font-size: 13px; margin: 0;">Nhấn để xem nội dung mẫu Footer này.</p>
            </div>
            <?php
        }
    }
    echo '</div>';
    echo '<style>.hbf-card:hover { border-color: #2271b1; box-shadow: 0 4px 12px rgba(0,0,0,0.1); transform: translateY(-2px); }</style>';
}