<?php
/**
 * Quản lý hiển thị danh sách các mẫu Header
 * Nhấp vào ô để xem nội dung file mẫu
 */

function hbf_render_header_tab() {
    $header_dir = HBF_PATH . 'header/';
    $files = glob($header_dir . "*.php");
    
    // Xử lý nạp nội dung file khi người dùng nhấp vào
    $view_file = isset($_GET['view_header']) ? sanitize_text_field($_GET['view_header']) : '';

    if ($view_file && file_exists($header_dir . $view_file)) {
        echo '<div style="margin-bottom: 20px;"><a href="?page=hbf-customizer&tab=header" class="button"><span class="dashicons dashicons-arrow-left-alt" style="vertical-align: middle; padding-top: 4px;"></span> Quay lại danh sách</a></div>';
        echo '<div class="hbf-preview-container" style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 4px;">';
        include $header_dir . $view_file; // Nạp nội dung file header1.php, header2.php...
        echo '</div>';
        return; // Dừng lại không hiển thị danh sách ô lưới nữa
    }

    echo '<div class="hbf-header-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 20px 0;">';

    if (!empty($files)) {
        foreach ($files as $file) {
            $file_name = basename($file);
            $display_title = ucfirst(str_replace('.php', '', $file_name));
            $link = "?page=hbf-customizer&tab=header&view_header=" . $file_name;

            ?>
            <div class="hbf-card" 
                 onclick="location.href='<?php echo $link; ?>'" 
                 style="background: #fff; border: 1px solid #e5e5e5; border-radius: 4px; padding: 40px 20px; text-align: center; cursor: pointer; transition: all 0.2s ease-in-out;">
                
                <div class="hbf-icon" style="margin-bottom: 15px;">
                    <span class="dashicons dashicons-portfolio" style="font-size: 40px; width: 40px; height: 40px; color: #2271b1;"></span>
                </div>
                
                <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 600; color: #1d2327;">
                    <?php echo esc_html($display_title); ?>
                </h3>
                
                <p style="color: #646970; font-size: 13px; margin: 0;">
                    Nhấn để xem nội dung mẫu này.
                </p>
            </div>
            <?php
        }
    } else {
        echo '<p style="grid-column: span 3; text-align: center; padding: 40px; background: #fff; border: 1px dashed #ccc;">Không tìm thấy file mẫu.</p>';
    }

    echo '</div>';
    echo '<style>.hbf-card:hover { border-color: #2271b1; box-shadow: 0 4px 12px rgba(0,0,0,0.1); transform: translateY(-2px); }</style>';
}