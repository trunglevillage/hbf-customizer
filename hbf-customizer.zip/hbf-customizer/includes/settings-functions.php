<?php
/**
 * File: includes/settings-functions.php
 * Chức năng: Quản lý cài đặt và xử lý lưu dữ liệu đúng quy trình WordPress
 */

// 1. Hàm xử lý lưu dữ liệu - Chèn vào hook 'admin_init' để đảm bảo an toàn
add_action('admin_init', function() {
    if (isset($_POST['hbf_save_settings'])) {
        // Kiểm tra bảo mật Nonce
        if (isset($_POST['hbf_settings_nonce']) && wp_verify_nonce($_POST['hbf_settings_nonce'], 'hbf_action_save')) {
            
            // Lưu trạng thái kích hoạt Header
            $auto_header = isset($_POST['hbf_auto_header']) ? '1' : '0';
            update_option('hbf_auto_header_active', $auto_header);
            
            // Lưu lựa chọn theme
            if (isset($_POST['hbf_theme_compat'])) {
                update_option('hbf_theme_compatibility', sanitize_text_field($_POST['hbf_theme_compat']));
            }

            // Đăng ký thông báo thành công
            add_settings_error(
                'hbf_settings_messages',
                'hbf_settings_updated',
                '✓ Đã cài đặt Header thành công!',
                'updated'
            );
        }
    }
});

// 2. Hàm hiển thị giao diện tab Cài đặt
function hbf_render_settings_tab() {
    // Hiển thị các thông báo (nếu có)
    settings_errors('hbf_settings_messages');

    $is_header_active = get_option('hbf_auto_header_active', '0');
    $current_theme = get_option('hbf_theme_compatibility', 'Auto');
    ?>

    <div class="wrap">
        <h3 style="margin-bottom: 20px;">Cấu hình nâng cao</h3>
        
        <form method="post" action="">
            <!-- Mã bảo mật Nonce[cite: 4] -->
            <?php wp_nonce_field('hbf_action_save', 'hbf_settings_nonce'); ?>

            <table class="form-table" style="background: #fff; padding: 10px; border: 1px solid #ccd0d4; border-radius: 4px;">
                <tr>
                    <th scope="row" style="padding-left: 20px;">Tương thích Theme</th>
                    <td>
                        <select name="hbf_theme_compat" style="min-width: 200px;">
                            <option value="Auto" <?php selected($current_theme, 'Auto'); ?>>Tự động phát hiện (Auto)</option>
                            <option value="GeneratePress" <?php selected($current_theme, 'GeneratePress'); ?>>GeneratePress</option>
                            <option value="Flatsome" <?php selected($current_theme, 'Flatsome'); ?>>Flatsome</option>
                        </select>
                        <p class="description">Chọn theme bạn đang dùng để plugin tối ưu hooks.</p>
                    </td>
                </tr>

                <tr style="border-top: 1px solid #eee;">
                    <th scope="row" style="padding-left: 20px;">Kích hoạt Header tự động</th>
                    <td>
                        <label for="hbf_auto_header" style="font-weight: 500;">
                            <input type="checkbox" id="hbf_auto_header" name="hbf_auto_header" value="1" <?php checked($is_header_active, '1'); ?>>
                            Sử dụng Shortcode <code style="color: #d63638;">[hbf_header1]</code> thay thế cho Header mặc định.
                        </label>
                        <p class="description">Khi bật, plugin sẽ tự động ẩn Header của Theme và hiển thị mẫu thiết kế của bạn.</p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" name="hbf_save_settings" class="button button-primary" style="padding: 0 30px;">Lưu thiết lập</button>
            </p>
        </form>

        <!-- Phần hiển thị Shortcode nằm phía dưới gạch (dưới nút Lưu)[cite: 4] -->
        <hr style="margin: 30px 0 20px 0; border: 0; border-top: 1px solid #ccd0d4;">
        
        <div class="hbf-shortcode-display" style="background: #e7f3ff; padding: 15px 20px; border-radius: 4px; border-left: 5px solid #2271b1; display: inline-block; min-width: 400px;">
            <p style="margin: 0; font-size: 14px; color: #1d2327;">
                <span style="font-weight: bold; margin-right: 15px;">🚀 Shortcode khả dụng:</span>
                <code style="color: #d63638; background: #fff; padding: 3px 8px; border-radius: 3px; border: 1px solid #ebbcbc; margin-right: 10px;">[hbf_header2]</code>
                <code style="color: #d63638; background: #fff; padding: 3px 8px; border-radius: 3px; border: 1px solid #ebbcbc;">[hbf_body2]</code>
            </p>
        </div>
    </div>

    <style>
        .form-table th { width: 250px; vertical-align: middle; }
        .notice { margin: 5px 0 15px 0 !important; }
        .hbf-shortcode-display code { font-weight: 600; font-family: 'Courier New', Courier, monospace; }
    </style>
    <?php
}