<?php
/**
 * Quản lý Menu Admin cho HBF Customizer
 * Tương thích WP 6.9.4+ & PHP 7.4+
 */

add_action('admin_menu', function() {
    add_menu_page(
        'HBF Customizer', 
        'HBF Customizer', 
        'manage_options', 
        'hbf-customizer', 
        'hbf_admin_page_layout', 
        'dashicons-layout', 
        100
    );
});

// Hàm hiển thị Grid mẫu - Tự động quét file từ thư mục
function hbf_render_template_grid($type) {
    $dir = HBF_PATH . $type . '/';
    $files = glob($dir . "*.php");
    
    echo '<div class="hbf-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; padding: 20px 0;">';
    if (!empty($files)) {
        foreach ($files as $file) {
            $file_name = basename($file);
            $display_name = ucfirst($type) . ' ' . str_replace(['.php', $type], '', $file_name);
            ?>
            <div class="hbf-card" style="background:#fff; border:1px solid #ddd; padding:35px 20px; text-align:center; border-radius:8px; cursor:pointer; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onclick="alert('Đã chọn mẫu: <?php echo esc_js($file_name); ?>')">
                <span class="dashicons dashicons-layout" style="font-size:45px; width:45px; height:45px; color:#2271b1; margin-bottom:15px;"></span>
                <h3><?php echo esc_html($display_name); ?></h3>
                <p>Nhấp để thiết kế</p>
            </div>
            <?php
        }
    } else {
        echo '<p>Chưa có file mẫu nào trong thư mục /' . esc_html($type) . '/. Hãy thêm file như ' . esc_html($type) . '1.php</p>';
    }
    echo '</div>';
}

function hbf_admin_page_layout() {
    $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'home';
    ?>
    <div class="wrap">
        <h1>HBF Customizer <small>v1.1</small></h1>
        
        <h2 class="nav-tab-wrapper">
            <a href="?page=hbf-customizer&tab=home" class="nav-tab <?php echo $tab == 'home' ? 'nav-tab-active' : ''; ?>">Tổng quan</a>
            <a href="?page=hbf-customizer&tab=header" class="nav-tab <?php echo $tab == 'header' ? 'nav-tab-active' : ''; ?>">Thiết kế Header</a>
            <a href="?page=hbf-customizer&tab=body" class="nav-tab <?php echo $tab == 'body' ? 'nav-tab-active' : ''; ?>">Thiết kế Body</a>
            <a href="?page=hbf-customizer&tab=footer" class="nav-tab <?php echo $tab == 'footer' ? 'nav-tab-active' : ''; ?>">Thiết kế Footer</a>
            <a href="?page=hbf-customizer&tab=settings" class="nav-tab <?php echo $tab == 'settings' ? 'nav-tab-active' : ''; ?>">Cài đặt</a>
        </h2>

        <div class="hbf-content" style="margin-top:20px;">
            <?php
            // Sử dụng switch case để nạp đúng file function hoặc nội dung tab[cite: 2]
            switch ($tab) {
                case 'header':
                    if (function_exists('hbf_render_header_tab')) hbf_render_header_tab();
                    break;
                case 'body':
                    if (function_exists('hbf_render_body_tab')) hbf_render_body_tab();
                    break;
                case 'footer':
                    if (function_exists('hbf_render_footer_tab')) hbf_render_footer_tab();
                    break;
                case 'settings':
                    if (function_exists('hbf_render_settings_tab')) hbf_render_settings_tab();
                    break;
                case 'home':
                default:
                    // Sửa đổi: Lấy nội dung từ đường dẫn plugins/hbf-customizer/overview.php
                    $overview_file = WP_PLUGIN_DIR . '/hbf-customizer/overview.php';
                    if (file_exists($overview_file)) {
                        include $overview_file;
                    } else {
                        echo "<h3>Chào mừng Quốc Thiều!</h3><p>Vui lòng tạo file <code>overview.php</code> để hiển thị nội dung Tổng quan.</p>";
                    }
                    break;
            }
            ?>
        </div>
    </div>
    <?php
}