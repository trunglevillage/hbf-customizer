<?php
/**
 * Template Name: Body 3 Custom Template
 * Author: Trần Quốc Thiều
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="hbf-body-template hbf-body-3" style="background: #fff5f5; border: 1px dashed #ff8a80; padding: 40px 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
    <div class="hbf-content-wrapper">
        <h3 style="color: #c62828; margin-bottom: 15px;">
            <i class="dashicons dashicons-layout" style="vertical-align: middle;"></i> 
            Phần Mẫu Body 3 đang cập nhật
        </h3>
        <p style="font-size: 16px; color: #333;">
            Chúng tôi đang hoàn thiện các cấu trúc Body đa dạng. Nếu bạn có ý tưởng mẫu cụ thể, hãy gửi yêu cầu vào nhóm Zalo bên dưới.
        </p>
        <div style="margin-top: 20px;">
            <a href="https://zalo.me/g/n0t7l3ikyqmz9brh0vnt" target="_blank" rel="nofollow" style="display: inline-block; background: #0068ff; color: #fff; padding: 12px 30px; border-radius: 5px; text-decoration: none; font-weight: bold;">
                Gửi yêu cầu mẫu Body 3
            </a>
        </div>
    </div>
</div>