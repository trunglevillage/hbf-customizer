<?php
if (!defined('ABSPATH')) exit;

/**
 * 1. XỬ LÝ AJAX & DỮ LIỆU
 */
add_action('wp_ajax_preview_shortcode_render', function() {
    $code = isset($_POST['shortcode']) ? stripslashes($_POST['shortcode']) : '';
    echo do_shortcode($code);
    wp_die();
});

// Sửa lại key option thành tem_body2_all_templates để đồng bộ
$all_templates = get_option('tem_body2_all_templates', []);

if (isset($_POST['save_template'])) {
    $tid = $_POST['template_id'];
    $all_templates[$tid]['style'] = isset($_POST['style']) ? stripslashes_deep($_POST['style']) : [];
    $all_templates[$tid]['blocks'] = isset($_POST['blocks']) ? stripslashes_deep($_POST['blocks']) : [];
    
    update_option('tem_body2_all_templates', $all_templates); // Cập nhật đồng bộ key mới
    echo '<div class="updated"><p>Đã lưu cấu hình Body 2 thành công!</p></div>';
}

wp_enqueue_media();
wp_enqueue_editor(); 
wp_enqueue_script('wp-color-picker');
wp_enqueue_style('wp-color-picker');
wp_enqueue_script('jquery-ui-sortable');

/**
 * 2. HÀM RENDER DÒNG BLOCK
 */
function render_block_row($bid, $data) {
    $type = isset($data['type']) ? $data['type'] : 'shortcode';
    $width = isset($data['width']) ? $data['width'] : '100';
    $img = isset($data['img']) ? $data['img'] : '';
    $url = isset($data['url']) ? $data['url'] : '';
    $content = isset($data['content']) ? $data['content'] : '';
    $code = isset($data['code']) ? $data['code'] : '';
    ?>
    <div class="block-item" data-type="<?php echo esc_attr($type); ?>" style="width: <?php echo $width; ?>%;">
        <div class="block-inner" style="margin: 5px; border: 1px solid #ddd; border-radius: 4px; background: #fff;">
            <div class="block-header" style="background: #f1f1f1; padding: 5px 12px; display: flex; align-items: center; gap: 15px;">
                <span class="handle dashicons dashicons-menu"></span>
                <span class="type-badge" style="background: #2271b1; color: #fff; padding: 2px 8px; border-radius: 3px; font-size: 10px; font-weight: bold; text-transform: uppercase;"><?php echo esc_html($type); ?></span>
                <div class="block-width-selector" style="font-size: 12px;">
                    <label>Độ rộng: </label>
                    <select name="blocks[<?php echo $bid; ?>][width]" class="select-block-width">
                        <option value="100" <?php selected($width, '100'); ?>>1 Cột (100%)</option>
                        <option value="50" <?php selected($width, '50'); ?>>2 Cột (50%)</option>
                    </select>
                </div>
                <span class="remove-btn dashicons dashicons-trash" style="margin-left: auto; cursor: pointer; color: #72777c;"></span>
            </div>
            <input type="hidden" name="blocks[<?php echo $bid; ?>][type]" value="<?php echo esc_attr($type); ?>">
            <div class="block-content" style="padding: 10px;">
                <?php if ($type == 'image'): ?>
                    <div class="flex-row" style="display: flex; gap: 10px; align-items: center;">
                        <img src="<?php echo esc_url($img); ?>" class="img-preview-thumb" style="width:50px; height:auto; border:1px solid #ddd; display: <?php echo $img ? 'block' : 'none'; ?>;">
                        <button type="button" class="button btn-upload">Chọn Ảnh</button>
                        <input type="hidden" class="in-img" name="blocks[<?php echo $bid; ?>][img]" value="<?php echo esc_attr($img); ?>">
                        <input type="text" name="blocks[<?php echo $bid; ?>][url]" placeholder="Link liên kết..." value="<?php echo esc_attr($url); ?>" style="flex:1">
                    </div>
                <?php elseif ($type == 'editor'): ?>
                    <div class="editor-wrap">
                        <textarea id="editor_<?php echo $bid; ?>" class="custom-tinymce" name="blocks[<?php echo $bid; ?>][content]" rows="8" style="width:100%;"><?php echo esc_textarea($content); ?></textarea>
                    </div>
                <?php else: ?>
                    <input type="text" class="in-sc" name="blocks[<?php echo $bid; ?>][code]" value="<?php echo esc_attr($code); ?>" placeholder="Dán Shortcode vào đây..." style="width:100%">
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}
?>

<style>
    .tem2-admin-wrap { margin-top: 20px; max-width: 1100px; }
    .template-card { background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin-bottom: 30px; }
    .style-config-grid { display: grid; grid-template-columns: 140px 1fr 140px 1fr; gap: 15px 25px; background: #f9f9f9; padding: 20px; border: 1px solid #eee; margin-bottom: 20px; align-items: center; }
    .blocks-container { display: flex; flex-wrap: wrap; margin: 0 -5px; background: #f0f0f1; padding: 10px; min-height: 100px; }
    .block-item { box-sizing: border-box; transition: width 0.3s ease; }
    .preview-container { display: flex; flex-wrap: wrap; box-sizing: border-box; overflow: hidden; }
    .preview-block-item { box-sizing: border-box; padding: 5px; min-height: 20px; }
    .preview-block-item[data-width="100"] { width: 100%; }
    .preview-block-item[data-width="50"] { width: 50%; }
    .preview-container img { max-width: 100%; height: auto; display: block; margin: 0 auto; }
    .device-switcher { display: flex; gap: 5px; margin-bottom: 15px; }
    .device-btn { background: #fff; border: 1px solid #2271b1; color: #2271b1; padding: 5px 12px; cursor: pointer; border-radius: 3px; }
    .device-btn.active { background: #2271b1; color: #fff; }
    .preview-frame { transition: all 0.3s ease; margin: 0 auto; background: #fff; border: 1px solid #dcdcde; padding: 0; }
    .preview-frame.desktop { width: 100%; }
    .preview-frame.tablet { width: 768px; }
    .preview-frame.mobile { width: 375px; }
</style>

<div class="wrap tem2-admin-wrap">
    <h1>Cấu hình Layout Body 2</h1>

    <?php 
    // Khởi tạo mảng trống nếu chưa có template nào để vòng lặp foreach không bị lỗi[cite: 3]
    if (empty($all_templates)) $all_templates = ['tpl_default' => ['style' => [], 'blocks' => []]];

    foreach ($all_templates as $tid => $tpl) : 
        $st = wp_parse_args(isset($tpl['style']) ? $tpl['style'] : [], [
            'bg_color'      => '#ffffff',
            'border_color'  => '#cccccc',
            'border_radius' => '0',
            'border_width'  => '1',
            'border_style'  => 'solid',
            'text_color'    => '#000000'
        ]);
    ?>
        <div class="template-card">
            <form method="post">
                <input type="hidden" name="template_id" value="<?php echo esc_attr($tid); ?>">
                
                <div class="style-config-grid">
                    <label>Màu nền</label> 
                    <input type="text" name="style[bg_color]" class="color-picker" value="<?php echo esc_attr($st['bg_color']); ?>">
                    <label>Màu viền</label> 
                    <input type="text" name="style[border_color]" class="color-picker" value="<?php echo esc_attr($st['border_color']); ?>">
                    <label>Bo góc (px)</label> 
                    <input type="number" name="style[border_radius]" value="<?php echo esc_attr($st['border_radius']); ?>">
                    <label>Độ dày viền (px)</label> 
                    <input type="number" name="style[border_width]" value="<?php echo esc_attr($st['border_width']); ?>">
                    <label>Kiểu viền</label> 
                    <select name="style[border_style]">
                        <option value="solid" <?php selected($st['border_style'], 'solid'); ?>>Solid</option>
                        <option value="dashed" <?php selected($st['border_style'], 'dashed'); ?>>Dashed</option>
                        <option value="dotted" <?php selected($st['border_style'], 'dotted'); ?>>Dotted</option>
                        <option value="none" <?php selected($st['border_style'], 'none'); ?>>None</option>
                    </select>
                    <label>Màu chữ</label> 
                    <input type="text" name="style[text_color]" class="color-picker" value="<?php echo esc_attr($st['text_color']); ?>">
                </div>

                <div class="blocks-container">
                    <?php if (!empty($tpl['blocks'])) { foreach ($tpl['blocks'] as $bid => $bdata) { render_block_row($bid, $bdata); } } ?>
                </div>

                <div style="margin-top:20px; display: flex; gap: 10px; background: #fff; padding: 15px; border: 1px dashed #ccc;">
                    <button type="button" class="button add-btn" data-type="image">Thêm Ảnh</button>
                    <button type="button" class="button add-btn" data-type="shortcode">Thêm Shortcode</button>
                    <button type="button" class="button add-btn" data-type="editor">Thêm Văn bản</button>
                    <button type="submit" name="save_template" class="button button-primary btn-save-tpl" style="margin-left:auto;">Lưu thay đổi</button>
                </div>
            </form>

            <h3 style="margin-top:40px;">Xem trước thực tế</h3>
            <div class="device-switcher">
                <button type="button" class="device-btn active" data-device="desktop">Desktop</button>
                <button type="button" class="device-btn" data-device="tablet">Tablet</button>
                <button type="button" class="device-btn" data-device="mobile">Mobile</button>
            </div>

            <div class="preview-frame desktop">
                <div class="preview-container" style="
                    background-color:<?php echo esc_attr($st['bg_color']); ?>; 
                    border:<?php echo esc_attr($st['border_width']); ?>px <?php echo esc_attr($st['border_style']); ?> <?php echo esc_attr($st['border_color']); ?>;
                    border-radius:<?php echo esc_attr($st['border_radius']); ?>px;
                    color:<?php echo esc_attr($st['text_color']); ?>;
                    padding:10px; display: flex; flex-wrap: wrap;">
                    <?php 
                    if (!empty($tpl['blocks'])) {
                        foreach ($tpl['blocks'] as $block) {
                            $bw = isset($block['width']) ? $block['width'] : '100';
                            echo '<div class="preview-block-item" data-width="'.$bw.'" style="width:'.$bw.'%;">';
                            if ($block['type'] === 'shortcode' && !empty($block['code'])) echo do_shortcode($block['code']);
                            elseif ($block['type'] === 'image' && !empty($block['img'])) echo '<img src="'.esc_url($block['img']).'">';
                            elseif ($block['type'] === 'editor' && !empty($block['content'])) echo wpautop(do_shortcode($block['content']));
                            echo '</div>';
                        }
                    } else {
                        echo '<p style="padding: 20px; text-align: center; width: 100%;">Chưa có dữ liệu để hiển thị.</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<script>
jQuery(document).ready(function($) {
    // Giữ nguyên các hàm JS xử lý Editor và Sortable
    function initEditor(id) {
        if (typeof tinymce !== 'undefined') {
            tinymce.execCommand('mceRemoveEditor', false, id);
            tinymce.init({
                selector: '#' + id,
                height: 200,
                menubar: false,
                setup: function (editor) { editor.on('change', function () { editor.save(); }); }
            });
        }
    }

    $('.custom-tinymce').each(function() { initEditor($(this).attr('id')); });
    $('.color-picker').wpColorPicker();

    $(".blocks-container").sortable({ handle: ".handle", placeholder: "ui-state-highlight" });

    $(document).on('change', '.select-block-width', function() {
        $(this).closest('.block-item').css('width', $(this).val() + '%');
    });

    $('.device-btn').click(function() {
        const dev = $(this).data('device');
        $(this).addClass('active').siblings().removeClass('active');
        $(this).closest('.template-card').find('.preview-frame').removeClass('desktop tablet mobile').addClass(dev);
    });

    $('.add-btn').click(function() {
        const type = $(this).data('type');
        const bid = 'b' + Date.now();
        const container = $(this).closest('form').find('.blocks-container');
        let content = '';
        
        if(type === 'image') {
            content = `<div class="flex-row" style="display: flex; gap: 10px; align-items: center;"><img src="" class="img-preview-thumb" style="width:50px; height:auto; border:1px solid #ddd; display:none;"><button type="button" class="button btn-upload">Chọn Ảnh</button><input type="hidden" class="in-img" name="blocks[${bid}][img]"><input type="text" name="blocks[${bid}][url]" placeholder="Link..." style="flex:1"></div>`;
        } else if(type === 'editor') {
            content = `<div class="editor-wrap"><textarea id="editor_${bid}" class="custom-tinymce" name="blocks[${bid}][content]" rows="8" style="width:100%;"></textarea></div>`;
        } else {
            content = `<input type="text" class="in-sc" name="blocks[${bid}][code]" placeholder="Shortcode..." style="width:100%">`;
        }
        
        container.append(`<div class="block-item" data-type="${type}" style="width: 100%;"><div class="block-inner" style="margin: 5px; border: 1px solid #ddd; border-radius: 4px; background: #fff;"><div class="block-header" style="background: #f1f1f1; padding: 5px 12px; display: flex; align-items: center; gap: 15px;"><span class="handle dashicons dashicons-menu"></span><span class="type-badge" style="background: #2271b1; color: #fff; padding: 2px 8px; border-radius: 3px; font-size: 10px; font-weight: bold; text-transform: uppercase;">${type}</span><div class="block-width-selector"><select name="blocks[${bid}][width]" class="select-block-width"><option value="100">100%</option><option value="50">50%</option></select></div><span class="remove-btn dashicons dashicons-trash" style="margin-left: auto; cursor: pointer;"></span></div><input type="hidden" name="blocks[${bid}][type]" value="${type}"><div class="block-content" style="padding: 10px;">${content}</div></div></div>`);
        
        if(type === 'editor') initEditor('editor_' + bid);
    });

    $(document).on('click', '.remove-btn', function() { $(this).closest('.block-item').remove(); });

    $(document).on('click', '.btn-upload', function(e) {
        e.preventDefault();
        const btn = $(this);
        const frame = wp.media({ multiple: false }).on('select', function() {
            const att = frame.state().get('selection').first().toJSON();
            btn.siblings('.img-preview-thumb').attr('src', att.url).show();
            btn.siblings('.in-img').val(att.url);
        }).open();
    });
    
    $('.btn-save-tpl').click(function() { if (typeof tinymce !== 'undefined') tinymce.triggerSave(); });
});
</script>