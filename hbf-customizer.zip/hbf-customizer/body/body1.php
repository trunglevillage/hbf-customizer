<?php
/**
 * Template Name: Body 1 Custom Template
 * Author: Trần Quốc Thiều
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="hbf-body-template hbf-body-1" style="background: #ffffff; border: 1px dashed #e0e0e0; padding: 40px 20px; text-align: center; border-radius: 8px; margin: 20px 0;">
    <div class="hbf-content-wrapper">
        <h3 style="color: #2c3e50; margin-bottom: 15px;">
            <i class="dashicons dashicons-edit" style="vertical-align: middle;"></i> 
            Phần Mẫu Body 1 đang cập nhật
        </h3>
        <p style="font-size: 16px; color: #666;">
            Nội dung chi tiết cho phần thân trang đang được thiết kế. Vui lòng liên hệ qua nhóm Zalo để yêu cầu mẫu Body cụ thể cho dự án của bạn.
        </p>
        <div style="margin-top: 20px;">
            <a href="https://zalo.me/g/n0t7l3ikyqmz9brh0vnt" target="_blank" rel="nofollow" style="display: inline-block; background: #0068ff; color: #fff; padding: 12px 30px; border-radius: 5px; text-decoration: none; font-weight: bold;">
                Tham gia Nhóm Zalo Hỗ Trợ
            </a>
        </div>
    </div>
</div>