<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_shortcode('hbf_header2', 'hbf_render_header2_final_fix');

function hbf_render_header2_final_fix() {
    $header1_options = get_option( 'giaodien_header1_options', [] );
    if ( empty( $header1_options ) ) return '';

    ob_start();
    ?>
    <style>
        .hbf-header-container { width: 100%; overflow: visible; } /* Đổi thành visible để hiện submenu */

        .hbf-nav-bar {
            background-color: <?php echo esc_attr( $header1_options['menu_background_color'] ?? '#c8102e' ); ?>;
            width: 100%;
            position: relative;
            z-index: 9999;
        }

        .hbf-menu-ul {
            display: flex;
            justify-content: center;
            list-style: none;
            margin: 0 auto;
            padding: 0;
            max-width: 1200px;
            flex-wrap: nowrap;
        }

        /* Quan trọng: Mục cha phải có position relative */
        .hbf-menu-ul > li {
            position: relative;
            display: block;
        }

        .hbf-menu-ul > li > a {
            text-decoration: none;
            color: <?php echo esc_attr( $header1_options['menu_text_color'] ?? '#ffffff' ); ?>;
            text-transform: uppercase;
            font-weight: bold;
            font-size: 13px;
            padding: 15px 18px;
            display: block;
            white-space: nowrap;
        }

        .hbf-menu-ul > li:hover > a {
            background: rgba(0,0,0,0.1);
        }

        /* Xử lý hiển thị Submenu khi di chuột vào */
        .hbf-menu-ul li ul {
            position: absolute;
            top: 100%; /* Nằm ngay dưới mục cha */
            left: 0;
            background: #ffffff;
            min-width: 250px;
            display: none; /* Mặc định ẩn */
            list-style: none;
            margin: 0;
            padding: 10px 0;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 10000;
            border-top: 3px solid <?php echo esc_attr( $header1_options['menu_background_color'] ?? '#c8102e' ); ?>;
        }

        /* Lệnh hiển thị khi Hover */
        .hbf-menu-ul li:hover > ul {
            display: block !important;
        }

        .hbf-menu-ul li ul li {
            width: 100%;
            display: block;
        }

        .hbf-menu-ul li ul li a {
            color: #333 !important;
            padding: 10px 20px;
            display: block;
            font-size: 14px;
            font-weight: normal;
            text-transform: none;
            text-decoration: none;
            border-bottom: 1px solid #f0f0f0;
            white-space: normal; /* Cho phép xuống dòng nếu tiêu đề con quá dài */
        }

        .hbf-menu-ul li ul li a:hover {
            background: #f8f8f8;
            color: <?php echo esc_attr( $header1_options['menu_background_color'] ?? '#c8102e' ); ?> !important;
        }

        /* Ẩn dấu chấm mặc định của WordPress menu */
        .hbf-menu-ul, .hbf-menu-ul ul { list-style-type: none !important; }
    </style>

    <div class="hbf-header-container">
        <!-- Khối Banner/Logo[cite: 3] -->
        <div class="hbf-main-header" style="
            background-color: <?php echo esc_attr($header1_options['background_color'] ?? '#ffffff'); ?>;
            min-height: <?php echo esc_attr($header1_options['header_height'] ?? '160'); ?>px;
            background-image: url(<?php echo esc_url($header1_options['background_image'] ?? ''); ?>);
            background-size: cover; background-position: center;
            display: flex; align-items: center; justify-content: center;">
            <div style="text-align: center;">
                <h3 style="color: <?php echo esc_attr($header1_options['main_title_color'] ?? '#ffffff'); ?>; margin: 0; font-size: 28px; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
                    <?php echo esc_html($header1_options['main_title'] ?? ''); ?>
                </h3>
            </div>
        </div>

        <!-- Thanh Menu[cite: 3] -->
        <nav class="hbf-nav-bar">
            <?php
            if ( ! empty( $header1_options['menu_slug'] ) ) {
                wp_nav_menu([
                    'menu' => $header1_options['menu_slug'],
                    'container' => false,
                    'menu_class' => 'hbf-menu-ul',
                    'fallback_cb' => false,
                    'depth' => 2 // Đảm bảo lấy được cả menu cấp 2
                ]);
            }
            ?>
        </nav>
    </div>
    <?php
    return ob_get_clean();
}