<?php
/**
 * Shortcode hiển thị Header 1
 * Đường dẫn: plugins/hbf-customizer/shortcode/header1-shortcode.php
 */

if (!defined('ABSPATH')) exit;

add_shortcode('hbf_header1', function() {
    // 1. Cấu hình mặc định
    $default_options = [
        'bg_color'       => '#d60000',
        'bg_image'       => '', 
        'header_height'  => '286',
        'dragon_left'    => '',
        'dragon_right'   => '',
        'logo_url'       => '',
        'menu_id'        => 0,
        'menu_shortcode' => '',
        'site_title'     => 'TRANG THÔNG TIN ĐIỆN TỬ',
        'site_desc'      => 'HỌ TRẦN LÊ ĐẠI TÔN',
        'bar_bg_color'   => '#b89851',
        'bar_text_color' => '#ffffff'
    ];
    
    // 2. Lấy dữ liệu từ database
    $options = get_option('header1_configs', $default_options);

    ob_start();
    ?>
    <div id="header1-display" class="hbf-header-output" style="
        background-color: <?php echo esc_attr($options['bg_color']); ?>; 
        background-image: url('<?php echo esc_url($options['bg_image']); ?>');
        height: <?php echo esc_attr($options['header_height']); ?>px;
        background-size: 100% 100%; background-repeat: no-repeat; width: 100%;">
        
        <div class="h1-main-wrapper" style="position: relative; display: flex; align-items: center; justify-content: center; height: calc(100% - 40px);">
            <div class="h1-logo-center" style="position: absolute; top: 10px; left: 50%; transform: translateX(-50%); z-index: 10;">
                <?php if (!empty($options['logo_url'])): ?>
                    <img src="<?php echo esc_url($options['logo_url']); ?>" style="max-height: 80px; width: auto;">
                <?php endif; ?>
            </div>

            <div class="h1-content-row" style="display: flex; width: 100%; align-items: center; justify-content: space-between; padding: 0 20px; margin-top: 40px;">
                <div class="h1-dragon-box left" style="width: 22%;">
                    <?php if (!empty($options['dragon_left'])): ?>
                        <img src="<?php echo esc_url($options['dragon_left']); ?>" style="width: 100%; max-height: 160px; object-fit: contain;">
                    <?php endif; ?>
                </div>

                <div class="h1-center-text" style="text-align: center; color: #fff; flex: 1; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">
                    <h1 style="font-size: 28px; text-transform: uppercase; margin: 0;"><?php echo esc_html($options['site_title']); ?></h1>
                    <p style="font-weight: bold; margin-top: 5px;"><?php echo esc_html($options['site_desc']); ?></p>
                </div>

                <div class="h1-dragon-box right" style="width: 22%;">
                    <?php if (!empty($options['dragon_right'])): ?>
                        <img src="<?php echo esc_url($options['dragon_right']); ?>" style="width: 100%; max-height: 160px; object-fit: contain;">
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="h1-bottom-bar" style="background-color: <?php echo esc_attr($options['bar_bg_color']); ?>; padding: 5px 0;">
            <div class="h1-inner-bar" style="color: <?php echo esc_attr($options['bar_text_color']); ?>; max-width: 1250px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 15px;">
                <div class="h1-date" style="font-size: 13px; font-weight: bold;"><?php echo date_i18n('l, d/m/Y'); ?></div>
                <nav class="h1-menu-nav">
                    <?php 
                    if (!empty($options['menu_id']) && $options['menu_id'] != '0') {
                        wp_nav_menu([
                            'menu' => $options['menu_id'],
                            'container' => false,
                            'menu_class' => 'h1-horizontal-menu'
                        ]);
                    } elseif (!empty($options['menu_shortcode'])) {
                        echo '<div class="h1-shortcode-wrap">' . do_shortcode($options['menu_shortcode']) . '</div>';
                    }
                    ?>
                </nav>
            </div>
        </div>
    </div>

    <style>
        ul.h1-horizontal-menu { list-style: none; margin: 0; padding: 0; display: flex; gap: 20px; }
        ul.h1-horizontal-menu li a { color: inherit; text-decoration: none; text-transform: uppercase; font-weight: bold; }
        @media (max-width: 768px) { .h1-dragon-box { display: none; } }
    </style>
    <?php
    return ob_get_clean();
});