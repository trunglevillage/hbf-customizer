<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [hbf_body2]
 * Chức năng: Chạy file body2.php nhưng chỉ lấy phần "Xem trước" để hiển thị ngoài giao diện.
 * Author: Trần Quốc Thiều
 */
add_shortcode('hbf_body2', 'hbf_render_body2_preview_only');

function hbf_render_body2_preview_only($atts) {
    // 1. Kiểm tra dữ liệu tồn tại để tránh lỗi
    $all_templates = get_option('tem_body2_all_templates', []);
    if (empty($all_templates)) {
        return '';
    }

    // 2. Chạy file body2.php và thu thập toàn bộ nội dung xuất ra
    ob_start();
    include HBF_PATH . 'body/body2.php';
    $full_output = ob_get_clean();

    // 3. Sử dụng biểu thức chính quy (Regex) để tách lấy phần "Xem trước thực tế"
    // Tìm đoạn nằm trong class "preview-frame" hoặc "preview-container"
    $pattern = '/<div class="preview-frame[^">]*">.*?<div class="preview-container".*?<\/div>.*?<\/div>/s';
    
    if (preg_match($pattern, $full_output, $matches)) {
        // Trả về chỉ phần HTML của khung xem trước
        return '<div class="hbf-body-frontend-wrapper">' . $matches[0] . '</div>';
    }

    // Dự phòng: Nếu không tìm thấy class cụ thể, ta sẽ lọc bỏ các thẻ <form> và các nút bấm Admin[cite: 2]
    $clean_output = preg_replace('/<form.*?>.*?<\/form>/s', '', $full_output);
    $clean_output = preg_replace('/<button.*?>.*?<\/button>/s', '', $clean_output);
    $clean_output = preg_replace('/<h1.*?>.*?<\/h1>/s', '', $clean_output);
    $clean_output = preg_replace('/<style.*?>.*?<\/style>/s', '', $clean_output); // Xóa style admin

    return $clean_output;
}