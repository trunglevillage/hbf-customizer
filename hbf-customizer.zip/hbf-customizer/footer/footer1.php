<?php
if (!defined('ABSPATH')) exit;

// 1. Lưu dữ liệu
if (isset($_POST['save_footer_settings'])) {
    update_option('footer_two_col_settings', $_POST['footer']);
    echo '<div class="notice notice-success is-dismissible"><p>✅ Cập nhật thành công!</p></div>';
}

// 2. Lấy dữ liệu
$opt = get_option('footer_two_col_settings', [
    'title' => 'NHÀ THỜ HỌ TRẦN LÊ ĐẠI TÔN',
    'bg_color' => '#00ffff',
    'text_color' => '#008080',
    'address' => 'Thôn Trung Khánh – Xã Đức Thịnh – Tỉnh Hà Tĩnh',
    'leader_prefix' => 'Ông',
    'leader_name' => 'Trần Đức Thọ',
    'leader_url' => '',
    'phone' => '0796.190.259',
    'bts_1_prefix' => 'Ông',
    'bts_1_name' => 'Trần Văn Kính',
    'bts_1_url' => '',
    'bts_2_prefix' => 'Ông',
    'bts_2_name' => 'Trần Đức Thuận',
    'bts_2_url' => '',
    'cv_1_prefix' => 'Ông',
    'cv_1_name' => 'Trần Điện Năng',
    'cv_1_url' => '',
    'cv_2_prefix' => 'Ông',
    'cv_2_name' => 'Lê Dĩnh Tuấn',
    'cv_2_url' => '',
    'copyright' => '© Bản quyền trang web này thuộc về DÒNG TỘC TRẦN LÊ ĐẠI TÔN',
    'note_text' => 'Mọi hành động sử dụng copy nội dung đăng tải phải được đồng ý...',
    'dev_text' => 'Phát triển bởi con cháu Dòng Tộc Trần Lê Đại Tôn',
    'extra_text_1' => 'Copyright © All rights reserved',
    'extra_html_center' => '',
    'extra_shortcode' => '[counter]',
    'map_embed' => ''
]);
?>

<div class="wrap-two-column">
    <div id="footer-preview-container" style="margin: 20px 0; border: 3px solid red; background: #fff; font-family: Arial, sans-serif;">
        <div style="display: flex; min-height: 250px;">
            <div style="flex: 2; padding: 20px; text-align: center; border-right: 1px solid #eee;">
                <div style="margin-bottom: 15px;">
                    <h2 id="pv-title" style="background: <?php echo $opt['bg_color']; ?>; color: <?php echo $opt['text_color']; ?>; padding: 10px; margin: 0; text-transform: uppercase; width: 100%; box-sizing: border-box; border-radius: 4px;">
                        <?php echo $opt['title']; ?>
                    </h2>
                </div>
                <p id="pv-address" style="color: #0073aa; font-weight: bold; margin-bottom: 5px;"><?php echo $opt['address']; ?></p>
                
                <p style="margin: 5px 0;">
                    <span style="color: red; font-weight: bold;">Tộc trưởng:</span> 
                    <a id="pv-leader_link" href="<?php echo esc_url($opt['leader_url']); ?>" style="text-decoration:none; color:inherit;" target="_blank">
                        <span id="pv-leader_prefix"><?php echo $opt['leader_prefix']; ?></span> <span id="pv-leader_name"><?php echo $opt['leader_name']; ?></span>
                    </a>: <strong id="pv-phone"><?php echo $opt['phone']; ?></strong>
                </p>
                
                <p style="margin: 5px 0;">
                    <strong style="color: #2e7d32;">Ban Trị Sự:</strong> 
                    <a id="pv-bts_1_link" href="<?php echo esc_url($opt['bts_1_url']); ?>" target="_blank"><span id="pv-bts_1_prefix"><?php echo $opt['bts_1_prefix']; ?></span> <span id="pv-bts_1_name"><?php echo $opt['bts_1_name']; ?></span></a> - 
                    <a id="pv-bts_2_link" href="<?php echo esc_url($opt['bts_2_url']); ?>" target="_blank"><span id="pv-bts_2_prefix"><?php echo $opt['bts_2_prefix']; ?></span> <span id="pv-bts_2_name"><?php echo $opt['bts_2_name']; ?></span></a>
                </p>
                
                <p style="margin: 5px 0;">
                    <strong>Ban cố vấn:</strong> 
                    <a id="pv-cv_1_link" href="<?php echo esc_url($opt['cv_1_url']); ?>" target="_blank"><span id="pv-cv_1_prefix"><?php echo $opt['cv_1_prefix']; ?></span> <span id="pv-cv_1_name"><?php echo $opt['cv_1_name']; ?></span></a> - 
                    <a id="pv-cv_2_link" href="<?php echo esc_url($opt['cv_2_url']); ?>" target="_blank"><span id="pv-cv_2_prefix"><?php echo $opt['cv_2_prefix']; ?></span> <span id="pv-cv_2_name"><?php echo $opt['cv_2_name']; ?></span></a>
                </p>
                
                <p id="pv-copyright" style="margin: 15px 0 10px 0; font-size: 14px;"><?php echo $opt['copyright']; ?></p>

                <div style="padding: 10px 0; margin-top: 5px; border-top: 1px solid #eee;">
                    <p id="pv-note" style="font-style: italic; margin: 0 0 5px 0; font-size: 13px; color: #555;"><?php echo $opt['note_text']; ?></p>
                    <h3 id="pv-dev" style="color: purple; margin: 0; font-size: 18px; font-weight: bold;"><?php echo $opt['dev_text']; ?></h3>
                </div>
            </div>
            
            <div style="flex: 1; background: #e8f5e9;">
                <div id="pv-map-container" style="width:100%; height:100%; min-height: 250px; overflow: hidden;">
                    <?php echo !empty($opt['map_embed']) ? stripslashes($opt['map_embed']) : ''; ?>
                </div>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 20px; border-top: 1px solid #eee; background: #fdfdfd; font-size: 13px;">
            <div id="pv-extra-1"><?php echo $opt['extra_text_1']; ?></div>
            <div id="pv-extra-html"><?php echo stripslashes($opt['extra_html_center']); ?></div>
            <div id="pv-extra-3"><?php echo do_shortcode($opt['extra_shortcode']); ?></div>
        </div>
    </div>

    <h3 style="background: #32373c; color: #fff; padding: 10px; margin: 0;">BẢNG TÙY CHỈNH NỘI DUNG</h3>
    <form method="post" style="background: #fff; padding: 20px; border: 1px solid #ccc; border-top: none;">
        <table class="form-table custom-footer-table">
            <tr>
                <th>Tên & Màu sắc</th>
                <td>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <input type="text" name="footer[title]" value="<?php echo esc_attr($opt['title']); ?>" class="regular-text input-live" data-target="pv-title" style="flex: 1;">
                        <span>Nền:</span> <input type="color" name="footer[bg_color]" value="<?php echo $opt['bg_color']; ?>" class="input-live-color" data-target="pv-title" data-prop="background">
                        <span>Chữ:</span> <input type="color" name="footer[text_color]" value="<?php echo $opt['text_color']; ?>" class="input-live-color" data-target="pv-title" data-prop="color">
                    </div>
                </td>
            </tr>
            <tr>
                <th>Địa chỉ & Bản quyền</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" name="footer[address]" value="<?php echo esc_attr($opt['address']); ?>" class="regular-text input-live" data-target="pv-address" style="flex: 1;" placeholder="Địa chỉ">
                        <input type="text" name="footer[copyright]" value="<?php echo esc_attr($opt['copyright']); ?>" class="regular-text input-live" data-target="pv-copyright" style="flex: 1;" placeholder="Dòng bản quyền">
                    </div>
                </td>
            </tr>
            <tr>
                <th>Tộc trưởng & SĐT</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <div style="display: flex; flex: 1; position: relative;">
                            <select name="footer[leader_prefix]" class="input-live-select" data-target="pv-leader_prefix">
                                <option value="Ông" <?php selected($opt['leader_prefix'], 'Ông'); ?>>Ông</option>
                                <option value="Bà" <?php selected($opt['leader_prefix'], 'Bà'); ?>>Bà</option>
                            </select>
                            <input type="text" name="footer[leader_name]" value="<?php echo esc_attr($opt['leader_name']); ?>" class="member-search-input input-live" data-target="pv-leader_name" data-link="pv-leader_link" data-url-field="leader_url_hidden" style="flex:1;" placeholder="Họ tên">
                            <input type="hidden" name="footer[leader_url]" id="leader_url_hidden" value="<?php echo esc_attr($opt['leader_url']); ?>">
                            <div class="search-results-dropdown"></div>
                        </div>
                        <input type="text" name="footer[phone]" value="<?php echo esc_attr($opt['phone']); ?>" class="regular-text input-live" data-target="pv-phone" placeholder="Số điện thoại" style="width: 200px;">
                    </div>
                </td>
            </tr>
            <tr>
                <th>Ban Trị Sự</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <div style="display: flex; flex: 1; position: relative;">
                            <select name="footer[bts_1_prefix]" class="input-live-select" data-target="pv-bts_1_prefix">
                                <option value="Ông" <?php selected($opt['bts_1_prefix'], 'Ông'); ?>>Ông</option>
                                <option value="Bà" <?php selected($opt['bts_1_prefix'], 'Bà'); ?>>Bà</option>
                            </select>
                            <input type="text" name="footer[bts_1_name]" value="<?php echo esc_attr($opt['bts_1_name']); ?>" class="member-search-input input-live" data-target="pv-bts_1_name" data-link="pv-bts_1_link" data-url-field="bts_1_url_hidden" style="flex:1;" placeholder="Thành viên 1">
                            <input type="hidden" name="footer[bts_1_url]" id="bts_1_url_hidden" value="<?php echo esc_attr($opt['bts_1_url']); ?>">
                            <div class="search-results-dropdown"></div>
                        </div>
                        <div style="display: flex; flex: 1; position: relative;">
                            <select name="footer[bts_2_prefix]" class="input-live-select" data-target="pv-bts_2_prefix">
                                <option value="Ông" <?php selected($opt['bts_2_prefix'], 'Ông'); ?>>Ông</option>
                                <option value="Bà" <?php selected($opt['bts_2_prefix'], 'Bà'); ?>>Bà</option>
                            </select>
                            <input type="text" name="footer[bts_2_name]" value="<?php echo esc_attr($opt['bts_2_name']); ?>" class="member-search-input input-live" data-target="pv-bts_2_name" data-link="pv-bts_2_link" data-url-field="bts_2_url_hidden" style="flex:1;" placeholder="Thành viên 2">
                            <input type="hidden" name="footer[bts_2_url]" id="bts_2_url_hidden" value="<?php echo esc_attr($opt['bts_2_url']); ?>">
                            <div class="search-results-dropdown"></div>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <th>Ban Cố Vấn</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <div style="display: flex; flex: 1; position: relative;">
                            <select name="footer[cv_1_prefix]" class="input-live-select" data-target="pv-cv_1_prefix">
                                <option value="Ông" <?php selected($opt['cv_1_prefix'], 'Ông'); ?>>Ông</option>
                                <option value="Bà" <?php selected($opt['cv_1_prefix'], 'Bà'); ?>>Bà</option>
                            </select>
                            <input type="text" name="footer[cv_1_name]" value="<?php echo esc_attr($opt['cv_1_name']); ?>" class="member-search-input input-live" data-target="pv-cv_1_name" data-link="pv-cv_1_link" data-url-field="cv_1_url_hidden" style="flex:1;" placeholder="Cố vấn 1">
                            <input type="hidden" name="footer[cv_1_url]" id="cv_1_url_hidden" value="<?php echo esc_attr($opt['cv_1_url']); ?>">
                            <div class="search-results-dropdown"></div>
                        </div>
                        <div style="display: flex; flex: 1; position: relative;">
                            <select name="footer[cv_2_prefix]" class="input-live-select" data-target="pv-cv_2_prefix">
                                <option value="Ông" <?php selected($opt['cv_2_prefix'], 'Ông'); ?>>Ông</option>
                                <option value="Bà" <?php selected($opt['cv_2_prefix'], 'Bà'); ?>>Bà</option>
                            </select>
                            <input type="text" name="footer[cv_2_name]" value="<?php echo esc_attr($opt['cv_2_name']); ?>" class="member-search-input input-live" data-target="pv-cv_2_name" data-link="pv-cv_2_link" data-url-field="cv_2_url_hidden" style="flex:1;" placeholder="Cố vấn 2">
                            <input type="hidden" name="footer[cv_2_url]" id="cv_2_url_hidden" value="<?php echo esc_attr($opt['cv_2_url']); ?>">
                            <div class="search-results-dropdown"></div>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <th>Ghi chú & Phát triển</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" name="footer[note_text]" value="<?php echo esc_attr($opt['note_text']); ?>" class="input-live" data-target="pv-note" style="flex: 1;" placeholder="Dòng ghi chú nhỏ">
                        <input type="text" name="footer[dev_text]" value="<?php echo esc_attr($opt['dev_text']); ?>" class="input-live" data-target="pv-dev" style="flex: 1;" placeholder="Phát triển bởi...">
                    </div>
                </td>
            </tr>
            <tr>
                <th>Thông tin dưới cùng</th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <input type="text" name="footer[extra_text_1]" value="<?php echo esc_attr($opt['extra_text_1']); ?>" class="input-live" data-target="pv-extra-1" style="flex: 1;" placeholder="Ô bên trái">
                        <input type="text" name="footer[extra_html_center]" id="extra-html-input" value="<?php echo esc_attr($opt['extra_html_center']); ?>" style="flex: 1;" placeholder="Ô HTML giữa">
                        <input type="text" name="footer[extra_shortcode]" id="shortcode-input" value="<?php echo esc_attr($opt['extra_shortcode']); ?>" style="flex: 0.5;" placeholder="Shortcode phải">
                    </div>
                </td>
            </tr>
            <tr>
                <th>Mã nhúng Bản đồ</th>
                <td><textarea name="footer[map_embed]" id="map-input" rows="2" class="large-text"><?php echo esc_textarea($opt['map_embed']); ?></textarea></td>
            </tr>
        </table>
        <p class="submit"><input type="submit" name="save_footer_settings" class="button button-primary" value="LƯU THAY ĐỔI"></p>
    </form>
</div>

<style>
.custom-footer-table th { width: 180px; font-weight: 600; padding: 15px 10px; border-bottom: 1px solid #f0f0f0; }
.custom-footer-table td { padding: 10px; border-bottom: 1px solid #f0f0f0; }
.search-results-dropdown { position: absolute; top: 100%; left: 0; right: 0; z-index: 99; background: #fff; border: 1px solid #ddd; max-height: 180px; overflow-y: auto; display:none; }
.result-item { padding: 8px 12px; border-bottom: 1px solid #eee; cursor: pointer; }
.result-item:hover { background: #f0f7ff; }
#pv-map-container iframe { width: 100% !important; height: 100% !important; border: 0 !important; }
</style>

<script type="text/javascript">
jQuery(document).ready(function($) {
    $('.input-live').on('input', function() { $('#' + $(this).data('target')).text($(this).val()); });
    $('.input-live-select').on('change', function() { $('#' + $(this).data('target')).text($(this).val()); });
    $('.input-live-color').on('input', function() { $('#' + $(this).data('target')).css($(this).data('prop'), $(this).val()); });
    $('#extra-html-input').on('input', function() { $('#pv-extra-html').html($(this).val()); });
    $('#shortcode-input').on('input', function() { $('#pv-extra-3').text($(this).val()); });

    $('.member-search-input').on('keyup', function() {
        var $input = $(this);
        var $dropdown = $input.siblings('.search-results-dropdown');
        var term = $input.val();
        if (term.length < 2) { $dropdown.hide(); return; }
        $.post(ajaxurl, { action: 'ajax_search_family', term: term }, function(res) {
            if (res.success && res.data.length > 0) {
                var html = '';
                res.data.forEach(function(item) {
                    html += '<div class="result-item" data-title="'+item.title+'" data-url="'+item.url+'"><strong>' + item.title + '</strong><small>Đời ' + item.gen + ' | Cha: ' + item.father + '</small></div>';
                });
                $dropdown.html(html).show();
            } else { $dropdown.hide(); }
        });
    });

    $(document).on('click', '.result-item', function() {
        var $dropdown = $(this).closest('.search-results-dropdown');
        var $input = $dropdown.siblings('.member-search-input');
        var title = $(this).data('title');
        var url = $(this).data('url');
        $input.val(title);
        $('#' + $input.data('url-field')).val(url);
        $('#' + $input.data('target')).text(title);
        $('#' + $input.data('link')).attr('href', url);
        $dropdown.hide();
    });

    $('#map-input').on('input', function() {
        var code = $(this).val().trim();
        if (code.indexOf('<iframe') !== -1) $('#pv-map-container').html(code);
    });
});
</script>