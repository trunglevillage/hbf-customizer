<?php
/**
 * Template Name: Footer 2 Custom Template
 * Author: Trần Quốc Thiều
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="hbf-footer-template hbf-footer-2" style="background: #343a40; color: #ffffff; padding: 30px 20px; text-align: center; border-top: 3px solid #0068ff;">
    <div class="hbf-footer-content">
        <h4 style="margin-bottom: 10px;">Phần Mẫu Footer 2 đang cập nhật</h4>
        <p style="font-size: 14px; opacity: 0.8;">
            Thông tin chân trang (Footer) đang được cập nhật thêm các mẫu mới. Mọi chi tiết xin vui lòng liên hệ nhóm hỗ trợ.
        </p>
        <div style="margin-top: 15px;">
            <a href="https://zalo.me/g/n0t7l3ikyqmz9brh0vnt" target="_blank" rel="nofollow" style="color: #0068ff; background: #fff; padding: 8px 20px; border-radius: 20px; text-decoration: none; font-weight: bold; font-size: 13px;">
                Kết nối qua Zalo
            </a>
        </div>
    </div>
</div>