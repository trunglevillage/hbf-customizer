<?php
/**
 * Template Name: Footer 3 Custom Template
 * Author: Trần Quốc Thiều
 */

if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="hbf-footer-template hbf-footer-3" style="background: #f1f3f5; border-top: 1px solid #dee2e6; padding: 30px 20px; text-align: center;">
    <div class="hbf-footer-content">
        <h4 style="color: #495057; margin-bottom: 10px;">Phần Mẫu Footer 3 đang cập nhật</h4>
        <p style="font-size: 14px; color: #868e96;">
            Bạn đang cần một mẫu chân trang chuyên nghiệp hơn? Hãy tham gia nhóm Zalo để nhận các mẫu thiết kế mới nhất.
        </p>
        <div style="margin-top: 15px;">
            <a href="https://zalo.me/g/n0t7l3ikyqmz9brh0vnt" target="_blank" rel="nofollow" style="display: inline-block; background: #0068ff; color: #fff; padding: 10px 25px; border-radius: 4px; text-decoration: none; font-weight: bold;">
                Yêu cầu mẫu Footer cụ thể
            </a>
        </div>
    </div>
</div>